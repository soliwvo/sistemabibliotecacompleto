// ===== PARTE 1: LISTAR =====
// Confere se a pessoa fez login; se não tiver token, manda de volta para a tela de login.
protegerPagina();
// Guarda em qual página da lista estamos. Começa na página 1. (let porque esse valor vai mudar)
let paginaAtual = 1;
// Quantos livros aparecem por página. (const porque esse valor nunca muda)
const limite = 5;
// Cria a função que busca os livros no servidor e monta a tabela. "async" permite usar await dentro dela.
async function carregarLivros() {
  // Pega o que foi digitado no campo de busca (id="busca-nome"). Se estiver vazio, busca todos.
  const nome = document.getElementById('busca-nome').value;
  // Tenta executar o bloco abaixo; se algo der errado, vai para o catch.
  try {
    // Pede a lista de livros ao servidor e ESPERA a resposta.
    // O endereço leva 3 informações depois do "?": a página, o limite de livros por página e o nome buscado.
    // Ex.: /livros?pagina=1&limite=5&nome=Dom
const resposta = await fetch(`/livros?pagina={limite}&nome=${nome}`, {
      // Envia o token no cabeçalho, porque a rota /livros é protegida (igual ao Thunder Client).
      headers: { 'Authorization': 'Bearer ' + pegarToken() },
    });
    // Se o token venceu (status 401), apaga o token, volta para o login e para a função aqui (return).
    if (tratarSessaoExpirada(resposta)) return;
    // Converte a resposta do servidor (texto JSON) em objeto JavaScript (aqui, uma lista de livros).
    const dados = await resposta.json();
    // Se o servidor respondeu com erro ("!" significa "não": se a resposta NÃO estiver ok)...
    if (!resposta.ok) {
      // ...mostra em vermelho a mensagem de erro. O "||" significa "ou": usa dados.mensagem e, se não existir, usa dados.erro.
      mostrarMensagem(dados.mensagem || dados.erro, 'erro');
      // Para a função aqui, sem montar a tabela.
      return;
    }
    // Procura no HTML o <tbody id="lista-livros"> e guarda na variável tabela.
    const tabela = document.getElementById('lista-livros');
    // Apaga tudo que estava dentro da tabela, para desenhar de novo do zero.
    tabela.innerHTML = '';
    // Se a lista de livros veio vazia (tamanho 0)...
    if (dados.length === 0) {
      // ...mostra uma linha avisando. colspan="5" faz essa célula ocupar as 5 colunas da tabela.
      tabela.innerHTML = '<tr><td colspan="5">Nenhum livro encontrado.</td></tr>';

    }
    // Repete os passos abaixo para CADA livro da lista. A cada volta, o livro atual fica na variável livro.
    dados.forEach(function (livro) {
      // Acrescenta (+=) uma nova linha <tr> na tabela, com os dados do livro.
      // As crases (`) permitem escrever o HTML em várias linhas e colocar valores com ${ }.
      tabela.innerHTML += `
        <tr>
          <!-- Coluna 1: o id do livro (número gerado pelo banco). -->
          <td>${livro.id}</td>
          <!-- Coluna 2: o título, passando pelo protegerTexto para evitar código 
malicioso (XSS). -->
          <td>${protegerTexto(livro.titulo)}</td>
          <!-- Coluna 3: o autor, também protegido. -->
          <td>${protegerTexto(livro.autor)}</td>
          <!-- Coluna 4: a quantidade em estoque. -->
          <td>${livro.quantidade_estoque}</td>
          <!-- Coluna 5: botão Excluir. Ao clicar, chama a função excluirLivro com o id 
deste livro (ela será criada no Passo 7). -->
          <td>
            <button type="button" class="botao botao-perigo botao-pequeno" 
onclick="excluirLivro(${livro.id})">Excluir</button>
          </td>
        </tr>
      `;
    // Fecha a função do forEach.
    });
    // Mostra na tela o número da página atual (no elemento id="numero-pagina").
    document.getElementById('numero-pagina').textContent = paginaAtual;
    // Desativa o botão "Anterior" quando estamos na página 1 (não existe página antes dela).
    document.getElementById('botao-anterior').disabled = paginaAtual === 1;
    // Desativa o botão "Próxima" quando vieram menos livros que o limite (sinal de que é a última página).
    document.getElementById('botao-proxima').disabled = dados.length < limite;
  // Se aconteceu uma falha no caminho (ex.: servidor desligado), cai aqui.
  } catch (erro) {
    // Mostra um aviso de erro de conexão em vermelho.
    mostrarMensagem('Não foi possível conectar ao servidor.', 'erro');
  }
// Fecha a função carregarLivros.
}
// Chama a função assim que a página abre, para a tabela já aparecer preenchida.
carregarLivros();

// Procura no HTML o formulário com id="form-livro" e guarda na variável formLivro.
const formLivro = document.getElementById('form-livro');
// Quando o formulário for enviado (botão Cadastrar ou tecla Enter), executa a função. "async" permite usar await.
formLivro.addEventListener('submit', async function (evento) {
  // Impede o comportamento padrão do formulário, que seria recarregar a página.
  evento.preventDefault();
  // Monta um objeto "livro" com os dados digitados no formulário (igual ao JSON do Body no Thunder Client).
  const livro = {
    // Pega o valor digitado no campo id="titulo".
    titulo: document.getElementById('titulo').value,
    // Pega o valor digitado no campo id="autor".
    autor: document.getElementById('autor').value,
    // Pega o valor do campo id="quantidade_estoque" e transforma em NÚMERO com Number().
    // (Tudo que vem de um campo da tela chega como texto: "5" em vez de 5.) quantidade_estoque: Number(document.getElementById('quantidade_estoque').value),
  // Fecha o objeto livro.
};
  // Tenta executar o bloco abaixo; se algo der errado, vai para o catch.
  try {
    // Envia um pedido ao servidor, na rota /livros, e ESPERA a resposta.
    const resposta = await fetch('/livros', {
      // Tipo do pedido: POST, usado para enviar (cadastrar) dados.
      method: 'POST',
      // Cabeçalhos do pedido: agora são DOIS.
      headers: {
        // Avisa ao servidor que o conteúdo enviado está em formato JSON.
        'Content-Type': 'application/json',
        // Envia o token guardado no login, porque a rota /livros é protegida.
        'Authorization': 'Bearer ' + pegarToken(),
      // Fecha os cabeçalhos.
      },
      // Transforma o objeto livro em texto JSON e coloca no corpo do pedido.
      body: JSON.stringify(livro),
    // Fecha as opções do fetch.
    });
    // Se o token venceu (status 401), apaga o token, volta para o login e para a função aqui.
    if (tratarSessaoExpirada(resposta)) return;
    // Converte a resposta do servidor (texto JSON) em objeto JavaScript.
    const dados = await resposta.json();
    // Se o servidor respondeu com sucesso (status 201 = criado)...
    if (resposta.ok) {

           // ...mostra a mensagem verde de sucesso...
      mostrarMensagem('Livro cadastrado com sucesso!', 'sucesso');
      // ...limpa todos os campos do formulário, para o próximo cadastro...
      formLivro.reset();
      // ...e recarrega a tabela, para o livro novo já aparecer na lista.
      carregarLivros();
    // Se o servidor respondeu com erro (ex.: campo obrigatório vazio)...
    } else {
      // ...mostra em vermelho a mensagem de erro (usa dados.mensagem ou, se não existir, dados.erro)
      mostrarMensagem(dados.mensagem || dados.erro, 'erro');
    }
  // Se aconteceu uma falha no caminho (ex.: servidor desligado), cai aqui.
  
} catch (erro) {
    // Mostra um aviso de erro de conexão em vermelho.
    mostrarMensagem('Não foi possível conectar ao servidor.', 'erro');
  }
// Fecha a função e o addEventListener.
});

// ===== PARTE 3: EXCLUIR =====
// Cria a função que exclui um livro. Ela recebe o id do livro que deve ser apagado.
// Quem chama essa função é o botão Excluir de cada linha da tabela: 
onclick="excluirLivro(${livro.id})"
async function excluirLivro(id) {
  // Abre uma caixinha perguntando se a pessoa tem certeza (botões OK e Cancelar).
  // confirm devolve true (OK) ou false (Cancelar). Com o "!", se a pessoa CANCELAR, a função para aqui (return).
  if (!confirm('Tem certeza que deseja excluir este livro?')) return;
  // Tenta executar o bloco abaixo; se algo der errado, vai para o catch.
  try {
    // Envia um pedido ao servidor para apagar o livro, e ESPERA a resposta.
    // O id vai no próprio endereço. Ex.: se o id for 3, o endereço fica /livros/3.
    const resposta = await fetch(`/livros/${id}`, {
      // Tipo do pedido: DELETE, usado para excluir dados.
      method: 'DELETE',
      // Envia o token, porque a rota é protegida. (Não tem Content-Type porque não enviamos corpo/JSON.)
      headers: { 'Authorization': 'Bearer ' + pegarToken() },
    // Fecha as opções do fetch.
    });
    // Se o token venceu (status 401), apaga o token, volta para o login e para a função aqui.
    if (tratarSessaoExpirada(resposta)) return;
    // Converte a resposta do servidor (texto JSON) em objeto JavaScript.
    const dados = await resposta.json();
    // Se o servidor respondeu com sucesso...
    if (resposta.ok) {
      // ...mostra em verde a mensagem que o próprio servidor mandou (ex.: "Livro excluído com sucesso")...
      mostrarMensagem(dados.mensagem, 'sucesso');
      // ...e recarrega a tabela, para o livro apagado sumir da lista.
      carregarLivros();
    // Se o servidor respondeu com erro (ex.: operador sem permissão para excluir)...
    } else {
      // ...mostra em vermelho a mensagem de erro (usa dados.mensagem ou, se não existir, dados.erro).
      mostrarMensagem(dados.mensagem || dados.erro, 'erro');
    }

      // Se aconteceu uma falha no caminho (ex.: servidor desligado), cai aqui.
  } catch (erro) {
    // Mostra um aviso de erro de conexão em vermelho.
    mostrarMensagem('Não foi possível conectar ao servidor.', 'erro');
  }
//
}

// ===== PARTE 4: BUSCA E PAGINAÇÃO =====
// Quando clicar no botão Buscar (id="botao-buscar")...
document.getElementById('botao-buscar').addEventListener('click', function () {
    // ...volta para a página 1, porque a busca nova pode ter menos resultados...
    paginaAtual = 1;
    // ...e recarrega a tabela. O carregarLivros já lê o que foi digitado no campo de 
  busca.
    carregarLivros();
  });
  // Quando clicar no botão Anterior (id="botao-anterior")...
  document.getElementById('botao-anterior').addEventListener('click', function () {
    // ...diminui 1 na página atual (ex.: da 2 para a 1)...
    paginaAtual = paginaAtual - 1;
    // ...e recarrega a tabela com a nova página.
    carregarLivros();
  });
  // Quando clicar no botão Próxima (id="botao-proxima")...
  document.getElementById('botao-proxima').addEventListener('click', function () {
    // ...soma 1 na página atual (ex.: da 1 para a 2)...
    paginaAtual = paginaAtual + 1;
    // ...e recarrega a tabela com a nova página.

    carregarLivros();
});

async function listar(req, res) {
    try {
      const movimentacoes = await Movimentacao.findAll({
        order: [['createdAt', 'DESC']],
      });
   
      res.json(movimentacoes);
    } catch (erro) {
      res.status(400).json({
        mensagem: 'Erro ao listar movimentações',
        erro: erro.message,
      });
    }
  }
   
  module.exports = { cadastrar, listar };

