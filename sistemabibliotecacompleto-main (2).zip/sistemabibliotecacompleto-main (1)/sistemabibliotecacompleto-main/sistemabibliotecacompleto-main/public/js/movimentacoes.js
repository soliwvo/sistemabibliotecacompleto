// ===== PARTE 1: CARREGAR OS LIVROS NA LISTA =====
// Confere se a pessoa fez login; se não tiver token, manda de volta para a tela de login.
protegerPagina();
// Cria uma lista vazia para guardar os livros que vierem do servidor.
// Ela fica FORA da função porque vai ser usada depois, na Parte 2 (histórico), para descobrir o título de cada livro.
let livros = [];
// Cria a função que busca os livros no servidor e preenche a lista de seleção (o <select>).
async function carregarLivrosNaLista() {
  // Tenta executar o bloco abaixo; se algo der errado, vai para o catch.
  try {
    // Pede os livros ao servidor e ESPERA a resposta.
    // limite=100 pede até 100 livros de uma vez, para TODOS aparecerem na lista (e não só os 5 da paginação).
    const resposta = await fetch('/livros?limite=100', {
      // Envia o token no cabeçalho, porque a rota /livros é protegida.
      headers: { 'Authorization': 'Bearer ' + pegarToken() },
    // Fecha as opções do fetch.
    });
    // Se o token venceu (status 401), apaga o token, volta para o login e para a função aqui.
    if (tratarSessaoExpirada(resposta)) return;
    // Converte a resposta do servidor (texto JSON) em objeto JavaScript (aqui, uma lista de livros).
    const dados = await resposta.json();

        // Se o servidor respondeu com erro ("!" = "não": se a resposta NÃO estiver ok)...
        if (!resposta.ok) {
            // ...mostra em vermelho a mensagem de erro (usa dados.mensagem ou, se não existir, dados.erro).
            mostrarMensagem(dados.mensagem || dados.erro, 'erro');
            // Para a função aqui, sem montar a lista.
            return;
          }
          // Guarda os livros recebidos na variável livros (aquela criada lá em cima, fora da função).
          livros = dados;
          // Procura no HTML a lista de seleção com id="livro_id" e guarda na variável lista.
          const lista = document.getElementById('livro_id');
          // Apaga as opções antigas e coloca só a primeira opção, "Selecione um livro".
          // value="" (vazio) faz o formulário não aceitar o envio sem escolher um livro de 
      verdade.
          lista.innerHTML = '<option value="">Selecione um livro</option>';
          // Repete os passos abaixo para CADA livro da lista. A cada volta, o livro atual fica na variável livro.
          livros.forEach(function (livro) {
            // Acrescenta (+=) uma nova opção na lista de seleção:
            // - value="${livro.id}" → o valor que vai ser ENVIADO ao servidor (o id do livro);
            // - o texto entre as tags → o que a pessoa VÊ na tela (título + estoque atual).
            // O título passa pelo protegerTexto para evitar código malicioso (XSS).
            lista.innerHTML += `
              <option value="{protegerTexto(livro.titulo)} (estoque: 
      ${livro.quantidade_estoque})</option>
            `;
          // Fecha a função do forEach.
          });
        // Se aconteceu uma falha no caminho (ex.: servidor desligado), cai aqui.
        } catch (erro) {
          // Mostra um aviso de erro de conexão em vermelho.
          mostrarMensagem('Não foi possível conectar ao servidor.', 'erro');
        }
      // Fecha a função carregarLivrosNaLista.
      }

// ===== PARTE 2: CARREGAR O HISTÓRICO =====
// Cria a função que busca as movimentações no servidor e monta a tabela do histórico.
async function carregarHistorico() {
  // Tenta executar o bloco abaixo; se algo der errado, vai para o catch.
  try {
    // Pede a lista de movimentações ao servidor (a rota GET criada no Passo 9) e ESPERA a resposta.
    const resposta = await fetch('/movimentacoes', {
      // Envia o token no cabeçalho, porque a rota /movimentacoes é protegida.
      headers: { 'Authorization': 'Bearer ' + pegarToken() },
    // Fecha as opções do fetch.
    });
    // Se o token venceu (status 401), apaga o token, volta para o login e para a função aqui.
    if (tratarSessaoExpirada(resposta)) return;
    // Converte a resposta do servidor (texto JSON) em objeto JavaScript (aqui, uma lista de movimentações).
    const dados = await resposta.json();
    // Se o servidor respondeu com erro ("!" = "não": se a resposta NÃO estiver ok)...
    if (!resposta.ok) {
      // ...mostra em vermelho a mensagem de erro (usa dados.mensagem ou, se não existir, dados.erro).
      mostrarMensagem(dados.mensagem || dados.erro, 'erro');
      // Para a função aqui, sem montar a tabela.
      return;
    }
    // Procura no HTML o <tbody id="lista-movimentacoes"> e guarda na variável tabela.
    const tabela = document.getElementById('lista-movimentacoes');
    // Apaga tudo que estava dentro da tabela, para desenhar de novo do zero.
    tabela.innerHTML = '';
    // Se a lista de movimentações veio vazia (tamanho 0)...
    if (dados.length === 0) {
      // ...mostra uma linha avisando. colspan="4" faz essa célula ocupar as 4 colunas da tabela.
      tabela.innerHTML = '<tr><td colspan="4">Nenhuma movimentação registrada. </td></tr>';
    }
    // Repete os passos abaixo para CADA movimentação. A cada volta, a movimentação atual fica na variável mov.
    dados.forEach(function (mov) {

      // A movimentação só traz o NÚMERO do livro (livro_id), não o título.
      // Então procuramos, na lista "livros" (carregada na Parte 1), o livro que tem esse mesmo id.
      // find devolve o PRIMEIRO livro que fizer a condição ser verdadeira (ou undefined, se não achar nenhum).
      const livro = livros.find(function (l) {
        // Condição: o id do livro "l" é igual ao livro_id da movimentação?
        // percorre a lista livros, um por um, até achar o livro
        return l.id === mov.livro_id;
      // Fecha a função do find.
      });
      // Se achou o livro, usa o título dele; se não achou (ex.: livro excluído), mostra "Livro nº" + o número.
      // Formato: condição ? valor_se_sim : valor_se_não
      const titulo = livro ? livro.titulo : 'Livro nº ' + mov.livro_id;
      // Transforma a data de criação da movimentação (createdAt) em data brasileira. Ex.: 15/10/2026.
      const data = new Date(mov.createdAt).toLocaleDateString('pt-BR');
      // Se o tipo for 'entrada', mostra "Entrada"; senão, mostra "Saída" (com letra maiúscula e acento, para ficar bonito na tela).
      const textoTipo = mov.tipo === 'entrada' ? 'Entrada' : 'Saída';
      // Acrescenta (+=) uma nova linha <tr> na tabela, com os dados da movimentação.
      // Colunas: data | título do livro (protegido contra XSS) | etiqueta colorida do tipo | quantidade.
      // class="etiqueta ${mov.tipo}" vira "etiqueta entrada" ou "etiqueta saida", e o CSS pinta cada uma de uma cor.
      tabela.innerHTML += `
        <tr>
          <td>${data}</td>
          <td>${protegerTexto(titulo)}</td>
          <td><span class="etiqueta {textoTipo}</span></td>
          <td>${mov.quantidade}</td>
        </tr>
      `;
    // Fecha a função do forEach.
    });
  // Se aconteceu uma falha no caminho (ex.: servidor desligado), cai aqui.
  } catch (erro) {
    // Mostra um aviso de erro de conexão em vermelho.
    mostrarMensagem('Não foi possível conectar ao servidor.', 'erro');
  }
// Fecha a função carregarHistorico.
}
// Cria a função que liga a tela, chamando as outras duas NA ORDEM certa.
async function iniciar() {
  // 1º: carrega os livros e ESPERA terminar (o histórico precisa da lista "livros" para achar os títulos).
  await carregarLivrosNaLista();
  // 2º: só depois carrega o histórico.

  await carregarHistorico();
// Fecha a função iniciar.
}
// Chama a função iniciar assim que a página abre.
iniciar();

// ===== PARTE 3: REGISTRAR =====
// Procura no HTML o formulário com id="form-movimentacao" e guarda na variável formMovimentacao.
const formMovimentacao = document.getElementById('form-movimentacao');
// Quando o formulário for enviado (botão Registrar ou tecla Enter), executa a função. "async" permite usar await.
formMovimentacao.addEventListener('submit', async function (evento) {
  // Impede o comportamento padrão do formulário, que seria recarregar a página.
  evento.preventDefault();
  // Monta um objeto "movimentacao" com os dados escolhidos no formulário (igual ao JSON do Body no Thunder Client).
  const movimentacao = {
    // Pega o id do livro escolhido na lista (id="livro_id") e transforma em NÚMERO.
    // (O value da opção é o id do livro, montado na Parte 1.)
    livro_id: Number(document.getElementById('livro_id').value),
    // Pega o tipo escolhido no campo id="tipo": 'entrada' ou 'saida'. Fica como texto mesmo.
    tipo: document.getElementById('tipo').value,

    // Pega a quantidade digitada no campo id="quantidade" e transforma em NÚMERO.
    quantidade: Number(document.getElementById('quantidade').value),
  // Fecha o objeto movimentacao.
  };
  // Tenta executar o bloco abaixo; se algo der errado, vai para o catch.
  try {
    // Envia um pedido ao servidor, na rota /movimentacoes, e ESPERA a resposta.
    const resposta = await fetch('/movimentacoes', {
      // Tipo do pedido: POST, usado para enviar (registrar) dados.
      method: 'POST',
      // Cabeçalhos do pedido: são DOIS.
      headers: {
        // Avisa ao servidor que o conteúdo enviado está em formato JSON.
        'Content-Type': 'application/json',
        // Envia o token guardado no login, porque a rota é protegida.
        // É também pelo token que o back-end descobre QUEM fez a movimentação (usuario_id).
        'Authorization': 'Bearer ' + pegarToken(),
      // Fecha os cabeçalhos.
      },
      // Transforma o objeto movimentacao em texto JSON e coloca no corpo do pedido.
      body: JSON.stringify(movimentacao),
    // Fecha as opções do fetch.
    });
    // Se o token venceu (status 401), apaga o token, volta para o login e para a função aqui.
    if (tratarSessaoExpirada(resposta)) return;
    // Converte a resposta do servidor (texto JSON) em objeto JavaScript.
    const dados = await resposta.json();
    // Se o servidor respondeu com sucesso (status 201 = criado)...
    if (resposta.ok) {
      // ...mostra a mensagem verde de sucesso...
      mostrarMensagem('Movimentação registrada com sucesso!', 'sucesso');
      // ...limpa todos os campos do formulário...
      formMovimentacao.reset();
      // ...e recarrega TUDO: a lista de livros (com o estoque novo) e o histórico (com a movimentação nova).
      iniciar();
    // Se o servidor respondeu com erro (ex.: "Quantidade insuficiente em estoque")...
    } else {
      // ...mostra em vermelho a mensagem de erro (usa dados.mensagem ou, se não existir, dados.erro).
      mostrarMensagem(dados.mensagem || dados.erro, 'erro');
    }

      // Se aconteceu uma falha no caminho (ex.: servidor desligado), cai aqui.
  } catch (erro) {
    // Mostra um aviso de erro de conexão em vermelho.
    mostrarMensagem('Não foi possível conectar ao servidor.', 'erro');
  }
// Fecha a função e o addEventListener.
});

